﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpMeApp.Services.Models.Registration
{
    public class RegistrationResponseModel
    {
        public bool IsSuccessful { get; set; }
        public string Message { get; set; }
    }
}
