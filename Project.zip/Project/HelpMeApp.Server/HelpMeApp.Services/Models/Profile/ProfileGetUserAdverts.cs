﻿using HelpMeApp.Services.Models.Advert;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpMeApp.Services.Models.Profile
{
    public class ProfileGetUserAdverts
    {
        public AdvertPreviewResponseData UserAdvert { get; set; }
    }
}
