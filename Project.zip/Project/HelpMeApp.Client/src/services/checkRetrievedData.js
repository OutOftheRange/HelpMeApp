const checkRetrievedData = (data) => {
    return data ?? "No data";
};

export default checkRetrievedData;
