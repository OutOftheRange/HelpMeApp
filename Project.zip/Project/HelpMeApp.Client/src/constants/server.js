export const serverUrl = "https://localhost:7049";
