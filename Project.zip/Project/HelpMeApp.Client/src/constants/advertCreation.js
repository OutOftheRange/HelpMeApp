const advertCreation = {
    helpTypes: ["Need help", "Can help"],
    categories: ["Food", "Clothes", "Evacuation", "Repairs"],
    terms: ["1", "2-3", "5-7", "10-20", "21-30"]
};

export default advertCreation;
